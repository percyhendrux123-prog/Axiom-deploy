#!/bin/sh
# Unprivileged Linux-only test wrapper; never shipped to the website.
BUNDLE="$HOME/.cache/ms-playwright/webkit-2370/minibrowser-wpe"
LOCAL="$(dirname "$(readlink -f "$0")")/webkit-deps/root/usr/lib/aarch64-linux-gnu"
export WEBKIT_EXEC_PATH="$BUNDLE/bin"
export WEBKIT_INJECTED_BUNDLE_PATH="$BUNDLE/lib"
export WEBKIT_INSPECTOR_RESOURCES_PATH="$BUNDLE/share"
export LD_LIBRARY_PATH="$BUNDLE/lib:$BUNDLE/sys/lib:$LOCAL"
export WEBKIT_FORCE_COMPLEX_TEXT=1
exec "$BUNDLE/bin/MiniBrowser" "$@"
