import { chromium, webkit } from '/home/cua/repos/Axiom-deploy/node_modules/playwright/index.mjs';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { writeFile } from 'node:fs/promises';
const root = '/home/cua/repos/Axiom-deploy', base = 'http://127.0.0.1:8795', results = [];
const baselineCSS = execFileSync('git', ['show', '57dfe87:assets/axioma/axioma.css'], { cwd: root, encoding: 'utf8' });
async function save(row) { results.push(row); await writeFile('/tmp/a300-final-second/custom-probes.json', JSON.stringify(results, null, 2)); console.log(JSON.stringify(row)); }
const arrive = (p,s) => p.locator(s).evaluate(e => scrollTo(0,e.getBoundingClientRect().top + scrollY - 90));
const dimensions = p => p.locator('.caduceus').evaluate(e => {const r=e.getBoundingClientRect(),s=getComputedStyle(e);return {w:r.width,h:r.height,left:r.left,right:r.right,font:parseFloat(s.fontSize),line:parseFloat(s.lineHeight),overflow:s.overflow,rows:e.textContent.split('\n').length,documentWidth:document.documentElement.scrollWidth};});
for (const [engine,type] of [['chromium',chromium],['webkit',webkit]]) {
  const browser = await type.launch({ headless:true, ...(engine === 'webkit' ? {executablePath:root+'/qa/a300/webkit-local.sh'} : {}) });
  try {
    for (const width of [1440,390]) {
      const context = await browser.newContext({viewport:{width,height:1000},reducedMotion:'reduce'});
      try {
        const page = await context.newPage(), errors=[]; page.on('pageerror',e=>errors.push(e.message));
        await page.goto(base); await page.evaluate(()=>document.fonts.ready); await arrive(page,'#system'); await page.waitForSelector('.has-terminal');
        assert.ok((await page.locator('#system').ariaSnapshot()).includes('OWNER → OPERATOR → WORKERS:'), 'clipped relationship summary remains in accessibility snapshot');
        const native = await page.locator('[data-system-node]').evaluateAll(es=>es.map(e=>({key:e.dataset.systemNode,tag:e.tagName,type:e.type,disabled:e.disabled,controls:e.getAttribute('aria-controls')})));
        assert.equal(native.length,11); assert.ok(native.every(e=>e.tag==='BUTTON'&&e.type==='button'&&!e.disabled));
        for (const n of native) {
          const el=page.locator('[data-system-node='+n.key+']'); await el.focus(); await page.keyboard.press('Space');
          assert.equal(await el.getAttribute('aria-pressed'),'true'); assert.equal(await page.locator('#'+n.controls).isVisible(),true);
          assert.ok(await el.evaluate(e=>{const s=getComputedStyle(e);return document.activeElement===e&&s.outlineStyle==='solid'&&parseFloat(s.outlineWidth)>=2;}),'visible keyboard focus on '+n.key);
          await page.keyboard.press('Escape'); assert.equal(await page.locator('#system-intro-info').isVisible(),true);
        }
        const canvas=await page.locator('#system canvas').evaluate(c=>{const r=c.getBoundingClientRect();return {width:c.width,height:c.height,cssWidth:r.width,cssHeight:r.height,dpr:devicePixelRatio};});
        assert.ok(Math.abs(canvas.width-canvas.cssWidth*canvas.dpr)<=1&&Math.abs(canvas.height-canvas.cssHeight*canvas.dpr)<=1);
        assert.deepEqual(errors,[]); await save({engine,width,enhancedAT:true,nativeSpaceEscapeFocusKeys:native.length,canvas});
      } finally { await context.close(); }
      const staticContext = await browser.newContext({viewport:{width,height:1000},javaScriptEnabled:false});
      try {
        const page=await staticContext.newPage(); await page.goto(base); await page.evaluate(()=>document.fonts.ready); await arrive(page,'.gate');
        const current=await page.locator('.caduceus').screenshot(), before=await dimensions(page); assert.equal(before.rows,18);
        assert.equal(await page.locator('.system__details>div:visible').count(),12); assert.equal(await page.locator('[data-system-node]:disabled').count(),11);
        const fallback=await page.locator('.system__alternative').evaluate(e=>({height:e.getBoundingClientRect().height,clip:getComputedStyle(e).clipPath}));
        assert.ok(fallback.height>24&&fallback.clip==='none');
        assert.ok((await page.locator('#system').ariaSnapshot()).includes('OWNER → OPERATOR → WORKERS:'));
        await page.route('**/axioma.css*',r=>r.fulfill({status:200,contentType:'text/css',body:baselineCSS})); await page.reload(); await page.evaluate(()=>document.fonts.ready); await arrive(page,'.gate');
        const original=await page.locator('.caduceus').screenshot(), old=await dimensions(page);
        assert.ok(current.equals(original),'static art pixels unchanged from baseline CSS'); assert.deepEqual(before,old);
        await save({engine,width,noJS:true,staticArtPixelIdentical:true,bounds:before});
      } finally { await staticContext.close(); }
    }
    const context=await browser.newContext({viewport:{width:1440,height:1000},deviceScaleFactor:2});
    try {
      const page=await context.newPage();
      await page.addInitScript(()=>{window.__callbacks=0;const raf=requestAnimationFrame;window.requestAnimationFrame=fn=>raf.call(window,t=>{window.__callbacks++;fn(t);});});
      await page.goto(base); await page.evaluate(()=>document.fonts.ready); await arrive(page,'.gate');
      await page.waitForFunction(()=>document.querySelector('.caduceus').dataset.entrance==='settled');
      const sizes=[];
      for (const width of [320,321,375,390,414,700,701,768,900,1024,1200,1440]) {
        await page.setViewportSize({width,height:1000}); await page.waitForTimeout(60); const d=await dimensions(page);
        assert.equal(d.rows,18); assert.ok(Math.abs(d.h-18*d.font)<0.05,JSON.stringify(d));
        assert.ok(d.left>=0&&d.right<=width,JSON.stringify(d)); if(width>=390)assert.equal(d.documentWidth,width);
        assert.equal(d.overflow,'visible'); sizes.push({width,...d});
      }
      await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'));});
      await page.waitForTimeout(50);
      const frozen=await page.locator('.caduceus').innerHTML(), callbacks=await page.evaluate(()=>window.__callbacks);
      await page.waitForTimeout(350); assert.equal(await page.locator('.caduceus').innerHTML(),frozen); assert.equal(await page.evaluate(()=>window.__callbacks),callbacks);
      assert.equal(await page.evaluate(()=>window.__axConductor.raf||window.__axConductor.timer),0);
      await page.evaluate(()=>{delete document.hidden;document.dispatchEvent(new Event('visibilitychange'));});
      await page.emulateMedia({reducedMotion:'reduce'}); await page.setViewportSize({width:390,height:1000}); await page.waitForTimeout(100);
      const reduced=await dimensions(page); assert.equal(reduced.rows,18); assert.ok(Math.abs(reduced.h-18*reduced.font)<0.05);
      await page.emulateMedia({reducedMotion:'no-preference'}); await arrive(page,'.gate'); await page.waitForFunction(()=>document.querySelector('.caduceus').classList.contains('is-live'));
      await arrive(page,'#system'); await page.waitForSelector('.has-terminal');
      const sharp=await page.locator('#system canvas').evaluate(c=>{const r=c.getBoundingClientRect();return {width:c.width,height:c.height,cssWidth:r.width,cssHeight:r.height,dpr:devicePixelRatio};});
      assert.ok(Math.abs(sharp.width-sharp.cssWidth*2)<=1&&Math.abs(sharp.height-sharp.cssHeight*2)<=1);
      await save({engine,liveResize:true,sizes,simulatedHiddenRAFStopped:true,motionToggleResponsive:true,dpr2:sharp});
    } finally { await context.close(); }
    const missingHome = await browser.newContext({viewport:{width:390,height:1000}});
    try {
      const page=await missingHome.newPage(); await page.route('**/home.js*',r=>r.abort()); await page.goto(base); await page.evaluate(()=>document.fonts.ready); await arrive(page,'#system'); await page.waitForSelector('.has-terminal-engine');
      const fallback=await page.locator('.system__alternative').evaluate(e=>({height:e.getBoundingClientRect().height,clip:getComputedStyle(e).clipPath})); assert.ok(fallback.height>24&&fallback.clip==='none');
      assert.equal(await page.locator('.system__details>div:visible').count(),12); await save({engine,missingHomeFallbackVisible:true});
    } finally { await missingHome.close(); }
  } finally { await browser.close(); }
}
console.log('All custom probes passed; evidence /tmp/a300-final-second/custom-probes.json');
