from pathlib import Path
import hashlib
import json
import subprocess
import zipfile
root = Path(__file__).resolve().parents[2]
qa = root / 'qa/a300'
load = lambda name: json.loads((qa / name).read_text())
base = '57dfe87bf337e1b67212830acef9724541fa453e'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
summary = {'base': base, 'implementation_head': head, 'engines': load('engine-info.json'), 'widths': {}, 'original_webkit_repeats': [], 'final_webkit_repeats': []}
for engine in ['chromium', 'webkit']:
    for width in [1440, 390]:
        key = f'{engine}-{width}'
        before = load(f'before-{key}-terminal-heights.json')
        after = load(f'after-{key}-terminal-heights.json')
        gate = load(f'after-{key}-gate-heights.json')
        scroll = load(f'after-{key}-scroll.json')
        summary['widths'][key] = {
            'frame_before_first_draw': before['before']['.system__frame']['height'],
            'frame_after_first_draw': before['after']['.system__frame']['height'],
            'frame_fixed_before': after['before']['.system__frame']['height'],
            'frame_fixed_after': after['after']['.system__frame']['height'],
            'layout_shift_supported': next(e['layoutShiftSupported'] for e in summary['engines'] if e['engine'] == engine),
            'before_delayed_draw_shift_sum': before['layoutShiftSum'] if engine == 'chromium' else None,
            'after_delayed_draw_shift_sum': after['layoutShiftSum'] if engine == 'chromium' else None,
            'empty_frame_before': load(f'before-{key}-gate-heights.json')['emptyFrame'],
            'empty_frame_after': gate['emptyFrame'],
            'art_settled_height': gate['after']['.caduceus']['height'],
            'gate_before': gate['before']['.gate']['height'], 'gate_after': gate['after']['.gate']['height'],
            'board_before': gate['before']['.system__board']['height'], 'board_after': gate['after']['.system__board']['height'],
            'scroll_steps': len(scroll['steps']),
            'max_scroll_error': max(abs(r['scrollY'] - r['previousY'] - 50) for r in scroll['steps']),
            'max_system_document_top_drift': max(abs(r['#system']['documentTop'] - scroll['first']['#system']['documentTop']) for r in scroll['steps'])}
for path in sorted(qa.glob('base-repro-*-scroll.json')):
    d = json.loads(path.read_text())
    summary['original_webkit_repeats'].append({'file': path.name, 'unexpected_steps': [dict(i=i, previousY=r['previousY'], scrollY=r['scrollY'], actual_delta=r['scrollY'] - r['previousY']) for i, r in enumerate(d['steps']) if r['scrollY'] - r['previousY'] != 50]})
for path in sorted(qa.glob('final-repeat-*-scroll.json')):
    d = json.loads(path.read_text())
    error = max(abs(r['scrollY'] - r['previousY'] - 50) for r in d['steps'])
    drift = max(abs(r['#system']['documentTop'] - d['first']['#system']['documentTop']) for r in d['steps'])
    assert error == drift == 0, path
    summary['final_webkit_repeats'].append({'file': path.name, 'steps': len(d['steps']), 'max_scroll_error': error, 'max_system_document_top_drift': drift})
assert len(summary['original_webkit_repeats']) == 8
assert len(summary['final_webkit_repeats']) == 16
summary['final_repeat_steps'] = sum(r['steps'] for r in summary['final_webkit_repeats'])
summary['original_jump_runs'] = sum(bool(r['unexpected_steps']) for r in summary['original_webkit_repeats'])
summary['tests'] = {}
for key, name in [('npm_test', 'after-npm-test.log'), ('chromium_browser_suite', 'after-browser-suite.log'), ('cross_engine_scroll_suite', 'after-scroll-tests.log')]:
    lines = (qa / name).read_text().splitlines()
    passed = int(next(line.split()[-1] for line in lines if line.startswith('ℹ pass ')))
    failed = int(next(line.split()[-1] for line in lines if line.startswith('ℹ fail ')))
    assert failed == 0
    summary['tests'][key] = {'pass': passed, 'fail': failed}
summary['unchanged_source_sha256'] = {}
for file in ['assets/axioma/caduceus.js', 'assets/axioma/home.js']:
    original = subprocess.check_output(['git', 'show', f'{base}:{file}'], cwd=root)
    current = (root / file).read_bytes()
    assert original == current
    summary['unchanged_source_sha256'][file] = hashlib.sha256(current).hexdigest()
(root / 'docs/A300-EVIDENCE-SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
files = [p for p in qa.iterdir() if p.is_file() and p.suffix in {'.png', '.json', '.log'} and (p.name.startswith(('before-', 'after-', 'base-repro-', 'final-repeat-')) or p.name in {'fallback-red.log', 'npm-build.log', 'npm-audit.log', 'static-build.log', 'native-codereview.log', 'engine-info.json', 'reviewer2-custom-probes.json'})]
files += [qa / 'webkit-local.sh', qa / 'reviewer2-probe.mjs', Path(__file__).resolve()]
files += [root / f'docs/{name}' for name in ['A300-HANDOFF.md', 'A300-REVIEW-BRIEF.md', 'A300-ADVERSARIAL-REVIEW.md', 'A300-EVIDENCE-SUMMARY.json']]
files += [root / file for file in ['assets/axioma/axioma.css', 'assets/axioma/chain-terminal.js', 'index.html', 'tests/browser/scroll-stability.test.mjs']]
contents = {str(p.relative_to(root)): p.read_bytes() for p in sorted(set(files))}
for file in ['assets/axioma/axioma.css', 'assets/axioma/chain-terminal.js']:
    contents['qa/a300/base-57dfe87/' + file] = subprocess.check_output(['git', 'show', f'{base}:{file}'], cwd=root)
manifest = '\n'.join(f'{hashlib.sha256(data).hexdigest()}  {name}' for name, data in sorted(contents.items())) + '\n'
archive = root / 'docs/A300-EVIDENCE.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as out:
    for name, data in contents.items():
        out.writestr(name, data)
    out.writestr('SHA256SUMS.txt', manifest)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for name, data in contents.items():
        assert hashlib.sha256(check.read(name)).digest() == hashlib.sha256(data).digest()
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size, 'files': len(contents) + 1, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'original_jump_runs': summary['original_jump_runs'], 'final_repeat_scenarios': len(summary['final_webkit_repeats']), 'final_repeat_steps': summary['final_repeat_steps']}, indent=2))
