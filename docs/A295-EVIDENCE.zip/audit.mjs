import { chromium } from 'playwright';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
const root = new URL('../..', import.meta.url).pathname;
const before = p => execFileSync('git', ['show', '81f2747:' + p], { cwd: root, encoding: 'utf8' });
const b = await chromium.launch();
const results = [];
try {
  for (const version of ['baseline', 'A295']) for (const width of [1440, 390]) {
    const context = await b.newContext({ viewport: { width, height: 900 }, reducedMotion: 'reduce' });
    try {
      const page = await context.newPage();
      if (version === 'baseline') {
        await page.route('**/assets/axioma/axioma.css*', route => route.fulfill({ contentType: 'text/css', body: before('assets/axioma/axioma.css') }));
        await page.route('**/assets/axioma/home.js*', route => route.fulfill({ contentType: 'text/javascript', body: before('assets/axioma/home.js') }));
        await page.route('http://127.0.0.1:8795/', route => route.fulfill({ contentType: 'text/html', body: before('index.html') }));
      }
      await page.goto('http://127.0.0.1:8795/');
      await page.evaluate(() => document.fonts.ready);
      await page.addScriptTag({ content: readFileSync(new URL('./axe.min.js', import.meta.url), 'utf8') });
      const scan = await page.evaluate(async () => {
        const r = await axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa'] } });
        return { axeVersion: axe.version, violations: r.violations.map(v => ({ id: v.id, impact: v.impact, nodes: v.nodes.map(n => ({ target: n.target, summary: n.failureSummary })) })), incomplete: r.incomplete.map(v => ({ id: v.id, targets: v.nodes.map(n => n.target) })), passes: r.passes.length };
      });
      results.push({ version, width, ...scan });
    } finally { await context.close(); }
  }
  writeFileSync(new URL('./axe-before-after.json', import.meta.url), JSON.stringify(results, null, 2) + '\n');
  console.log(JSON.stringify(results, null, 2));
  if (results.some(r => r.violations.length)) process.exitCode = 1;
} finally { await b.close(); }
