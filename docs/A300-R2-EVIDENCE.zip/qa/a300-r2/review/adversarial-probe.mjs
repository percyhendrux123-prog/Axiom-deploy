// Supplementary read-only A300 R2 reviewer probe; evidence only.
import assert from 'node:assert/strict';
import { readFile, stat, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { resolve, sep, extname, join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { chromium, webkit } from 'playwright';
const root = resolve(import.meta.dirname, '../../..');
const dist = join(root, 'dist');
const output = import.meta.dirname;
const oldCss = execFileSync('git', ['show', '4aac7d4:assets/axioma/axioma.css'], { cwd: root, encoding: 'utf8' });
const newCss = await readFile(join(root, 'assets/axioma/axioma.css'), 'utf8');
assert.equal(await readFile(join(dist, 'assets/axioma/axioma.css'), 'utf8'), newCss);
const fixture = await readFile(join(root, 'tests/browser/fixtures/a300-host-metrics.woff2'));
const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.webp': 'image/webp' };
const server = createServer(async (req, res) => {
  try {
    let file = resolve(dist, '.' + decodeURIComponent(new URL(req.url, 'http://localhost').pathname));
    if (!file.startsWith(dist + sep) && file !== dist) return res.writeHead(403).end();
    if ((await stat(file)).isDirectory()) file = join(file, 'index.html');
    res.writeHead(200, { 'content-type': types[extname(file)] || 'application/octet-stream' }).end(await readFile(file));
  } catch { res.writeHead(404).end(); }
});
await new Promise(done => server.listen(0, '127.0.0.1', done));
const base = `http://127.0.0.1:${server.address().port}`;
const summary = { staticComparisons: [], cursorControls: [], resized: [], failures: [] };
function geometry() {
  const pre = document.querySelector('.caduceus'), r = pre.getBoundingClientRect(), style = getComputedStyle(pre);
  const inner = document.querySelector('.gate__inner'), cr = inner.getBoundingClientRect(), cs = getComputedStyle(inner);
  const range = document.createRange(), rows = [];
  let row = [];
  const walk = document.createTreeWalker(pre, NodeFilter.SHOW_TEXT);
  while (walk.nextNode()) {
    const n = walk.currentNode;
    for (let i = 0; i < n.length; i++) {
      if (n.textContent[i] === '\n') { rows.push(row); row = []; continue; }
      range.setStart(n, i); range.setEnd(n, i + 1);
      const b = range.getBoundingClientRect(); row.push({ x: b.x, y: b.y - r.y, width: b.width, height: b.height });
    }
  }
  if (row.length) rows.push(row);
  return { slot: { x: r.x, width: r.width, height: r.height }, fontSize: style.fontSize, text: pre.textContent, rows,
    spans: [...pre.children].map(e => { const b = e.getBoundingClientRect(); return { x: b.x, width: b.width }; }),
    contentColumn: { left: cr.left + parseFloat(cs.paddingLeft), right: cr.right - parseFloat(cs.paddingRight) },
    scrollWidth: document.documentElement.scrollWidth, viewport: innerWidth, transform: style.transform, overflow: style.overflow };
}
async function open(browser, width, version, metrics, reducedMotion = 'reduce') {
  const context = await browser.newContext({ viewport: { width, height: 1000 }, reducedMotion });
  const page = await context.newPage(), errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.route('**/home.js*', route => route.abort());
  await page.route('**/__reviewer-metrics.woff2', route => route.fulfill({ contentType: 'font/woff2', body: fixture }));
  await page.route('**/axioma.css*', route => route.fulfill({ contentType: 'text/css', body: (version === 'old' ? oldCss : newCss) + (metrics ? '\n@font-face{font-family:ReviewerMetrics;src:url(/__reviewer-metrics.woff2)}.caduceus{font-family:ReviewerMetrics}' : '') }));
  await page.addInitScript(() => {
    window.__reviewerShifts = [];
    if (PerformanceObserver.supportedEntryTypes.includes('layout-shift')) new PerformanceObserver(list => {
      window.__reviewerShifts.push(...list.getEntries().map(e => ({ value: e.value, recent: e.hadRecentInput,
        sources: e.sources.map(s => ({ node: s.node?.tagName + '.' + s.node?.className, before: s.previousRect.toJSON(), after: s.currentRect.toJSON() })) })));
    }).observe({ type: 'layout-shift', buffered: true });
  });
  await page.goto(base); await page.evaluate(() => document.fonts.ready);
  await page.locator('.gate').evaluate(e => scrollTo(0, e.getBoundingClientRect().top + scrollY - 90));
  await page.waitForTimeout(50);
  return { context, page, errors };
}
try {
  for (const engine of (process.env.PROBE_ENGINES || 'webkit,chromium').split(',')) {
    const browser = await ({ chromium, webkit })[engine].launch({ headless: true, ...(engine === 'webkit' ? { executablePath: join(root, 'qa/a300/webkit-local.sh') } : {}) });
    try {
      for (const metrics of [false, true]) for (const width of [320, 390, 900, 901, 1024, 1440, 1920]) {
        const results = {};
        for (const version of ['old', 'new']) {
          const { context, page, errors } = await open(browser, width, version, metrics);
          try { results[version] = await page.evaluate(geometry); assert.deepEqual(errors, []); }
          finally { await context.close(); }
        }
        const a = results.old, b = results.new;
        assert.equal(a.text, b.text); assert.equal(a.fontSize, b.fontSize);
        assert.equal(b.transform, 'none'); assert.equal(b.overflow, 'visible');
        assert.equal(a.slot.height, b.slot.height); assert.equal(b.rows.length, 18);
        assert.equal(b.scrollWidth, a.scrollWidth, 'no newly introduced document overflow'); assert.ok(Math.abs(b.slot.x - b.contentColumn.left) < .02);
        assert.ok(Math.abs(b.slot.x + b.slot.width - b.contentColumn.right) < .02);
        let maximumGlyphDelta = 0;
        const deltas = { x: 0, y: 0, width: 0, height: 0 };
        for (let ri = 0; ri < a.rows.length; ri++) {
          assert.equal(b.rows[ri].length, 44);
          for (let gi = 0; gi < a.rows[ri].length; gi++) for (const key of ['x', 'y', 'width', 'height']) {
            const delta = Math.abs(a.rows[ri][gi][key] - b.rows[ri][gi][key]);
            maximumGlyphDelta = Math.max(maximumGlyphDelta, delta); deltas[key] = Math.max(deltas[key], delta);
          }
        }
        const rowWidthDelta = Math.max(...a.spans.map((s, i) => Math.abs(s.width - b.spans[i].width)));
        console.log(JSON.stringify({ engine, width, metrics, oldSlot: a.slot, slot: b.slot, deltas, rowWidthDelta }));
        assert.ok(rowWidthDelta < .02 && deltas.width <= 1 && deltas.height < .02 && deltas.x <= 1 && deltas.y <= 1, `${engine} ${width} metrics=${metrics}: glyph deltas ${JSON.stringify(deltas)}`);
        for (const s of b.spans) {
          assert.ok(s.x >= b.contentColumn.left && s.x + s.width <= b.contentColumn.right, 'actual glyph row fits column');
          assert.ok(Math.abs(s.x + s.width / 2 - width / 2) < 1, 'actual glyph row is centered within pixel rounding');
        }
        summary.staticComparisons.push({ engine, metrics, width, fontSize: b.fontSize, slot: b.slot, oldSlot: a.slot, scrollWidth: b.scrollWidth, oldScrollWidth: a.scrollWidth, maximumGlyphDelta, deltas, rowWidthDelta });
      }
      for (const width of [1440, 390]) for (const version of ['old', 'new']) {
        const { context, page, errors } = await open(browser, width, version, true);
        try {
          await page.addScriptTag({ path: join(root, 'assets/axioma/caduceus.js') });
          await page.evaluate(() => { window.__reviewerEngine = window.AxCaduceus.create(); });
          await page.waitForTimeout(80);
          await page.evaluate(() => { window.__reviewerShifts = []; });
          const frames = [];
          for (const reveal of [0, .24, .51, .99, 1, .1, 1]) {
            await page.locator('.caduceus').evaluate((pre, reveal) => { pre.innerHTML = window.__reviewerEngine.frame(0, 0, reveal); }, reveal);
            await page.waitForTimeout(90);
            frames.push({ reveal, ...await page.evaluate(geometry) });
          }
          const shifts = await page.evaluate(() => window.__reviewerShifts);
          const cls = shifts.reduce((s, e) => s + e.value, 0);
          const widthSpan = Math.max(...frames.map(f => f.slot.width)) - Math.min(...frames.map(f => f.slot.width));
          const leftSpan = Math.max(...frames.map(f => f.slot.x)) - Math.min(...frames.map(f => f.slot.x));
          if (version === 'new') { assert.equal(widthSpan, 0); assert.equal(leftSpan, 0); assert.equal(cls, 0); }
          else { assert.ok(widthSpan > 3); assert.ok(leftSpan > 1); if (engine === 'chromium' && width === 1440) assert.ok(cls > 0, 'negative-control desktop baseline must emit horizontal CLS'); }
          assert.deepEqual(errors, []);
          summary.cursorControls.push({ engine, width, version, cls, widthSpan, leftSpan, shifts, frameSlots: frames.map(f => ({ reveal: f.reveal, slot: f.slot })) });
          if (version === 'new') {
            for (const resizeWidth of [320, 1440, 390]) {
              await page.setViewportSize({ width: resizeWidth, height: 1000 });
              const resized = await page.evaluate(geometry);
              assert.ok(resized.scrollWidth <= resizeWidth + (resizeWidth === 320 ? 3 : 0)); assert.equal(resized.rows.length, 18);
              assert.ok(Math.abs(resized.slot.x - resized.contentColumn.left) < .02);
              summary.resized.push({ engine, originalWidth: width, resizeWidth, fontSize: resized.fontSize, slot: resized.slot });
            }
          }
        } finally { await context.close(); }
      }
    } finally { await browser.close(); }
  }
} catch (e) { summary.failures.push({ message: e.message, stack: e.stack }); process.exitCode = 1; }
finally { await new Promise(done => server.close(done)); await writeFile(join(output, 'adversarial-probe.json'), JSON.stringify(summary, null, 2)); }
console.log(JSON.stringify({ staticComparisons: summary.staticComparisons.length, cursorControls: summary.cursorControls.map(({ frames, shifts, frameSlots, ...r }) => r), resized: summary.resized.length, failures: summary.failures }, null, 2));
