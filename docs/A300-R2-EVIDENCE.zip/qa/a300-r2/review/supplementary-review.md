# Supplementary A300 R2 adversarial review

## Outcome

**No concrete introduced defects found** in the working diff against `4aac7d4`.
This is supplementary evidence only; it does not replace native codereview-profile or Mac Apple Braille acceptance.

## Scope verified

- Exact tracked diff remains four files, 91 insertions and 8 deletions. Production changes are only the `.caduceus` inline-size reservation/comment and CSS cache-key v10 to v11. Read the fixture generator/license and both changed browser tests.
- `git diff --check 4aac7d4` passed. `assets/axioma/caduceus.js` is byte-for-byte baseline (SHA-256 `235810aad7f9594a2e6f1146e17f2e08cd01a5149ad42857de36807985ca36fa`).
- Built CSS equals source CSS. No host-metric fixture occurs in `dist`. Did not run the build or full Chromium suite concurrently with the parent.

## Executed checks

1. Narrow existing WebKit host-metric entrance/55-step scroll cases: **2/2 passed**, at 1440x1000 and 390x1000. Command:

   `SCROLL_BROWSERS=webkit WEBKIT_EXECUTABLE="$PWD/qa/a300/webkit-local.sh" SCROLL_LABEL=reviewer SCREENSHOT_DIR=qa/a300-r2/review node --test --test-concurrency=1 --test-name-pattern='host-metric caduceus' tests/browser/scroll-stability.test.mjs`

2. Independent baseline-versus-revision probe `node qa/a300-r2/review/adversarial-probe.mjs`: **exit 0**, with results in `adversarial-probe.json` and `.log`:
   - 28 old/new static comparisons: Chromium and WebKit; normal fallback and host-metric font; widths 320, 390, 900, 901, 1024, 1440 and 1920. Same text, 44 cells by 18 rows, font size and slot height; exact unchanged full-row advance (maximum width delta 0). Actual glyph rows remain centered within 1px and fit their columns. No transform, clipping or newly introduced page overflow.
   - Eight deterministic cursor/settled controls: both engines at 1440 and 390, old and new CSS. New PRE width/left drift is exactly zero. Chromium new CLS is exactly zero at both widths, including all recorded entries without recent-input filtering. WebKit has no CLS API: its result is geometry, not an assertion of API-supported CLS.
   - Negative control reproduced old desktop horizontal CLS `0.005033351417824074` over several intentionally repeated cursor transitions. Old desktop width drift is 11px Chromium and 10.765625px WebKit; old mobile width drift 4px and 3.328125px respectively. Thus this probe detects the removed failure, rather than merely passing the revised code.
   - 12 desktop/mobile resize checks passed with stable full-column slots and unchanged art dimensions.
3. Inspected the native test's mobile-before and desktop-after screenshots: complete, centered wings and tails, no visible art clipping.

## Non-findings / probe calibration

- At 320px both old and revised pages report scrollWidth 323px in both engines. This is pre-existing and not reported as an introduced defect.
- WebKit individual-character Range rectangles can shift/snap by a pixel after changing the containing slot, although full-row element width is unchanged exactly. Maximum row-position difference was 0.921875px, within the existing <1px centering expectation. No scaling or row-width regression found.
- Old Chromium mobile PRE movement does not necessarily emit CLS (the observed left shift is only 2px), so the independent mobile negative control asserts geometry rather than requiring a nonzero API entry.

## Remaining gates / issues

- Real Mac Apple Braille and the required native codereview profile remain outside this Linux supplementary pass. Parent owns full-suite/npm acceptance.
- Standing proof was attempted in this session with the exact read-only argv `git -C /home/cua/repos/Axiom-deploy diff --stat 4aac7d4`, expecting the observed diff totals. Tool returned **unavailable**, handle `standing:68`, because the command is not owner-allowlisted. No pass or demotion was recorded. No passing Standing proof was obtained, and no kanban completion was performed. Owner/parent must arrange an allowlisted relevant target before closing the task.

## File effects

No tracked source, tests or docs edited; no commits/publication. Evidence only under `qa/a300-r2/review`: this report, independent probe `.mjs/.json/.log`, and the narrow WebKit test's `reviewer-*` screenshots/JSON.
