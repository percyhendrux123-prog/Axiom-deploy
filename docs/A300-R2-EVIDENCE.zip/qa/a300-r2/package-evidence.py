"""Aggregate real A300 rework traces and package portable evidence only."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

repo = Path(__file__).resolve().parents[2]
root = repo / 'qa/a300-r2'
summary = {'implementation_commit': '83fa07ef6b19d0f3dc595541859532585001b407',
           'review_base': '4aac7d46ec8eed4e1c6987669424b68a1bfa407f',
           'engines': ['chromium', 'webkit'], 'viewports': [1440, 390],
           'webkit_layout_shift_api_supported': False, 'metric_cases': {}, 'natural_scroll_cases': {}}
for phase in ('before', 'after'):
    cases = {}
    for p in sorted(root.glob(f'{phase}-*-host-metrics.json')):
        d = json.loads(p.read_text())
        rows = d['samples']
        cases[p.stem] = {
            'font_metrics': d['metrics'], 'initial_slot': d['first']['.caduceus'],
            'width_min': min(r['width'] for r in rows), 'width_max': max(r['width'] for r in rows),
            'width_drift': max(r['width'] for r in rows) - min(r['width'] for r in rows),
            'left_drift': max(r['left'] for r in rows) - min(r['left'] for r in rows),
            'layout_shift_sum': d['layoutShiftSum'] if 'chromium' in p.name else None,
            'cursor_frames': sum(bool(r['cursor']) for r in rows), 'steps': len(d['steps']),
            'max_scroll_error': max(abs(r['scrollY'] - r['previousY'] - 50) for r in d['steps']),
            'max_system_document_drift': max(abs(r['#system']['documentTop'] - d['first']['#system']['documentTop']) for r in d['steps'])}
        if phase == 'after':
            assert cases[p.stem]['width_drift'] == cases[p.stem]['left_drift'] == 0
            assert d['layoutShiftSum'] == 0
    assert len(cases) == 4
    summary['metric_cases'][phase] = cases
for p in sorted(root.glob('after-*-scroll.json')):
    d = json.loads(p.read_text())
    summary['natural_scroll_cases'][p.stem] = {
        'steps': len(d['steps']), 'layout_shift_sum': d['layoutShiftSum'] if 'chromium' in p.name else None,
        'max_scroll_error': max(abs(r['scrollY'] - r['previousY'] - 50) for r in d['steps']),
        'max_system_document_drift': max(abs(r['#system']['documentTop'] - d['first']['#system']['documentTop']) for r in d['steps'])}
assert len(summary['natural_scroll_cases']) == 4
summary['after_step_count'] = sum(d['steps'] for d in summary['metric_cases']['after'].values()) + sum(d['steps'] for d in summary['natural_scroll_cases'].values())
for name, expected in [('npm-test.log', 58), ('full-browser.log', 73), ('cross-engine.log', 20)]:
    text = (root / name).read_text()
    passed, failed = int(re.search(r'ℹ pass (\d+)', text)[1]), int(re.search(r'ℹ fail (\d+)', text)[1])
    assert passed == expected and failed == 0
    summary[name] = {'passed': passed, 'failed': failed}
probe = json.loads((root / 'review/adversarial-probe.json').read_text())
assert probe['failures'] == []
summary['supplementary_review'] = {'static_comparisons': len(probe['staticComparisons']),
                                   'cursor_controls': len(probe['cursorControls']),
                                   'resize_checks': len(probe['resized']), 'failures': probe['failures']}
summary['art_bounds'] = {p.stem: json.loads(p.read_text()) for p in (root / 'regression').glob('caduceus-size-*.json')}
summary['standing_proof'] = {'handle': 'standing:67', 'passed': True, 'target': 'https://deployaxiom.com',
                             'scope': 'Public reference HTTP only, not proof of unshipped code.'}
summary_path = repo / 'docs/A300-R2-EVIDENCE-SUMMARY.json'
summary_path.write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
files = [p for p in root.rglob('*') if p.is_file() and 'fonttools' not in p.relative_to(root).parts and p.suffix in ('.png', '.json', '.mjs', '.log', '.md', '.py') and p.name not in ('fonttools-install.log', 'package-evidence.log')]
files += [summary_path, repo / 'docs/A300-R2-HANDOFF.md', repo / 'docs/A300-R2-REVIEW-BRIEF.md',
          repo / 'docs/A300-R2-ADVERSARIAL-REVIEW.md']
files = sorted(set(files))
manifest = ''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + str(p.relative_to(repo)) + '\n' for p in files)
archive = repo / 'docs/A300-R2-EVIDENCE.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, str(p.relative_to(repo)))
    z.writestr('SHA256SUMS.txt', manifest)
print('Archive:', archive, 'files:', len(files), 'bytes:', archive.stat().st_size,
      'sha256:', hashlib.sha256(archive.read_bytes()).hexdigest())
